<?php
require 'vendor/autoload.php';

//echo "Inicio<br>";
session_start();
$app = new \Core\App();

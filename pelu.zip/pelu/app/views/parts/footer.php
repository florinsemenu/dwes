<footer class="footer fixed-bottom bg-dark text-white">
    <div class="text-center" style="margin: 10px">
        Pie de página
    </div>
</footer>

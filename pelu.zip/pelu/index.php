<?php
//Aquí llamo a la clase App y creo un objeto de esa clase
//luego llego al método run del objeto creado
require_once "core/App.php";
$app = new \Core\App();